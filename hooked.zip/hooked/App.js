import React from "react";
import ReactDOM from "react-dom";
import Header from "./src/components/Header.jsx";
import Body from "./src/components/Body.jsx";
// import RestaurantCard from "./src/components/RestaurantCard.jsx";
import Footer from "./src/components/Footer.jsx";

// const imgCdn = "https://media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_300,h_300,c_fit/"

const AppLayout = () => {
  return (
    <>
      <Header />
      <Body />
      <Footer />
    </>
  );
};

ReactDOM.render(<AppLayout />, document.getElementById("root"));