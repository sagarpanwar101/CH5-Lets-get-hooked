// import imgCdn 
import React from "react";
import ReactDOM from "react-dom/client";


const RestaurantCard = ({ name, cuisines, cloudinaryImageId, avgRating, lastMileTravelString }) => {
    return (
      <div className="card">
        <img src={ imgCdn + cloudinaryImageId } alt={name} />
        <span className="card-title">{name}</span>
        <span className="card-tags">{cuisines.join(", ")}</span>
        <span className="card-rating">{avgRating}</span>
        <h4>{lastMileTravelString} minutes</h4>
      </div>
    );
  };

  
  export default RestaurantCard;