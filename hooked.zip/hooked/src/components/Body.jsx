import React from "react";
import restaurantList from "./RestaurantList";

const Body = () => {
    return (
      <RestaurantList />
    );
  };

  export default Body;